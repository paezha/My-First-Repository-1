#' WTPBr: A package with...
#'
#' This package is an exercise in package creation using
#' R studio. The package includes a sample function and
#' a sample dataset with their respective documentation.
#'
#' @docType package
#' @name WTPBr
#' @author Tatiana Ferrari, School of Geography and Earth Sciences, McMaster University \email{paezha@@mcmaster.ca}
#' @references \url{https://github.com/TatianaFerrari/My-First-Repository}
NULL